This directory contains interesting applications,

e.g. denoising an image
